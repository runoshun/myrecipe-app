const handler = require("./dist").default;
exports.handler = handler;